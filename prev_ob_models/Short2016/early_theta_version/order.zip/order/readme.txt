These programs demonstrate the order of execution in 
NEURON mod files.


recomended usage:
i686/special order1.hoc > output